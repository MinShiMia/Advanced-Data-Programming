#' Functions for nonparametric group comparisons.
#' 
#' npar provides tools for calculating and visualizing
#' nonparametric differences among groups.
#' 
#' @docType package
#' @name npar-package
#' @aliases npar
NULL


